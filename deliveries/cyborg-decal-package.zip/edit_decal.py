from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image, ImageCms, ImageDraw
from scipy.ndimage import distance_transform_edt, binary_dilation, gaussian_filter
P=Path(__file__).parent
src=P/'original.png'; before=hashlib.sha256(src.read_bytes()).hexdigest()
a=np.array(Image.open(src).convert('RGBA')); rgb=a[:,:,:3].astype(float)/255; alpha=a[:,:,3]; h,w=alpha.shape
y,x=np.mgrid[:h,:w]; mx=rgb.max(2); mn=rgb.min(2); chroma=mx-mn
# Explicit regional guard: red pigment in the heart/coolant zone, including its edge pixels.
red=(x>775)&(y>110)&(y<1060)&(rgb[:,:,0]>0.28)&(rgb[:,:,0]>rgb[:,:,1]*1.65)&(rgb[:,:,0]>rgb[:,:,2]*1.25)&(alpha>0)
red_guard=binary_dilation(red,iterations=3)
# Only neutral, bright reflections within opaque armor. Preserve face, heart, and contours.
inside=distance_transform_edt(alpha>240)>3
armor=(y>255)&~((x>780)&(y<600))
neutral=1-np.clip((chroma-.06)/.20,0,1)
bright=np.clip((mn-.62)/.30,0,1)
cut=neutral*bright*inside*armor*~red_guard
# Keep an explicit core of completely clear highlights; soften only the transition.
cut[cut>.85]=1
cut=np.clip(cut,0,1)
newalpha=np.rint(alpha*(1-cut)).astype('uint8')
# Gentle luminance-dependent midtone lift, with a common RGB gain to retain hue.
lum=rgb@np.array([.2126,.7152,.0722])
gain=1+.12*np.exp(-((lum-.30)/.23)**2)
gain=np.minimum(gain,1/np.maximum(mx,1e-6))
out_rgb=np.rint(np.clip(rgb*gain[:,:,None],0,1)*255).astype('uint8')
# Crimson is copied exactly: color and alpha. It receives no tone or knockout edits.
out_rgb[red]=a[:,:,:3][red]; newalpha[red]=alpha[red]
out=np.dstack([out_rgb,newalpha]); out[alpha==0]=a[alpha==0]
icc=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
def save(arr,name): Image.fromarray(arr).save(P/name,icc_profile=icc)
save(out,'cyborg-decal-RGBA.png')
Image.fromarray(newalpha).save(P/'transparency-mask.png')
Image.fromarray(np.rint(cut*255).astype('uint8')).save(P/'highlight-cutout-mask.png')
# Complementary layers reconstruct the final export exactly in alpha-over composition.
cool=out.copy(); cool[:,:,3]=np.where(red,newalpha,0)
base=out.copy(); base[:,:,3]=np.where(red,0,newalpha)
save(cool,'crimson-separation-RGBA.png'); save(base,'artwork-without-crimson-RGBA.png')
# Checkerboard shows actual transparency, not an ink/substrate prediction.
check=np.where(((x//20+y//20)%2)[:,:,None],np.array([175,175,175]),np.array([225,225,225]))
af=newalpha[:,:,None]/255
preview=np.rint(out_rgb*af+check*(1-af)).astype('uint8')
Image.fromarray(preview).resize((750,1000),Image.Resampling.LANCZOS).save(P/'transparency-preview.png')
# Illustrative dye transmission on a uniform dark substrate: not color managed proofing.
metal=np.array([62,59,54.]); transmit=out_rgb/255
simulation=np.rint(metal*(1-af)+metal*transmit*af).clip(0,255).astype('uint8')
Image.fromarray(simulation).save(P/'dark-metal-limitations-preview.png')
reopened=np.array(Image.open(P/'cyborg-decal-RGBA.png'))
comp=Image.alpha_composite(Image.open(P/'artwork-without-crimson-RGBA.png'),Image.open(P/'crimson-separation-RGBA.png'))
assert np.array_equal(np.array(comp)[newalpha>0],out[newalpha>0])
assert np.array_equal(reopened,out)
assert np.array_equal(newalpha[alpha==0],alpha[alpha==0])
assert np.all(newalpha<=alpha)
assert np.array_equal(out[red],a[red])
assert hashlib.sha256(src.read_bytes()).hexdigest()==before
stats={'size':[w,h],'mode':Image.open(P/'cyborg-decal-RGBA.png').mode,'original_sha256':before,'original_fully_transparent_pixels':int((alpha==0).sum()),'original_clear_pixels_preserved':True,'alpha_reduced_pixels':int((newalpha<alpha).sum()),'new_fully_clear_pixels':int(((newalpha==0)&(alpha>0)).sum()),'crimson_pixels_preserved_exactly':int(red.sum()),'complementary_layers_recombine_exactly_on_visible_pixels':True,'alpha_roundtrip_verified':True,'physical_print_proof':'not performed','printer_profile':'unknown; tagged sRGB, no CMYK conversion','resolution':'original 1086 x 1448; no upscaling or invented DPI'}
(P/'alpha-checks.json').write_text(json.dumps(stats,indent=2))
print(json.dumps(stats,indent=2))
